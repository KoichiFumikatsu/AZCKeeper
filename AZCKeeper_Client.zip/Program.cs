using System;
using System.Threading;
using System.Windows.Forms;
using AZCKeeper_Cliente.Core;
using AZCKeeper_Cliente.Logging;

namespace AZCKeeper_Cliente
{
    /// <summary>
    /// Punto de entrada principal de la aplicaci�n AZC Keeper Cliente.
    /// 
    /// Responsabilidades:
    /// - Configurar el manejo global de excepciones.
    /// - Garantizar que s�lo exista una instancia del cliente (Mutex).
    /// - Inicializar el n�cleo (CoreService).
    /// - Mantener un ApplicationContext "invisible" para que la app
    ///   corra en segundo plano sin ventanas principales.
    /// </summary>
    internal static class Program
    {
        /// <summary>
        /// Nombre del mutex para garantizar una sola instancia
        /// del proceso AZCKeeper_Cliente.
        /// </summary>
        private const string SingleInstanceMutexName = "AZCKeeper_Cliente_SingleInstance";

        /// <summary>
        /// M�todo Main: arranque de la aplicaci�n Windows.
        /// </summary>
        [STAThread]
        private static void Main()
        {
            // Configuramos manejadores globales de excepciones para registrar
            // cualquier error inesperado.
            AppDomain.CurrentDomain.UnhandledException += CurrentDomain_UnhandledException;
            Application.ThreadException += Application_ThreadException;

            // Mutex para asegurar que s�lo haya una instancia del cliente.
            using (var mutex = new Mutex(initiallyOwned: true, name: SingleInstanceMutexName, createdNew: out bool isNewInstance))
            {
                if (!isNewInstance)
                {
                    // Ya existe otra instancia: registramos y salimos.
                    LocalLogger.Warn("Se detect� una instancia previa de AZCKeeper_Cliente. Se aborta el arranque de la nueva instancia.");
                    return;
                }

                try
                {
                    Application.EnableVisualStyles();
                    Application.SetCompatibleTextRenderingDefault(false);

                    // N�cleo de la aplicaci�n.
                    var coreService = new CoreService();

                    // Secuencia de inicializaci�n del n�cleo (config, logger, API, m�dulos, etc.).
                    coreService.Initialize();

                    // Arranque de m�dulos (timers, trackers, etc.).
                    coreService.Start();

                    // ApplicationContext m�nimo sin formularios principales visibles.
                    using (var context = new ApplicationContext())
                    {
                        Application.Run(context);
                    }

                    // Al salir del loop de mensajes, detenemos ordenadamente los m�dulos.
                    coreService.Stop();
                }
                catch (Exception ex)
                {
                    // Cualquier excepci�n no manejada en Main se registra aqu�.
                    LocalLogger.Error(ex, "Error cr�tico durante el arranque/ejecuci�n de la aplicaci�n en Main().");
                }
            }
        }

        /// <summary>
        /// Maneja excepciones no controladas en hilos de Windows Forms.
        /// </summary>
        private static void Application_ThreadException(object sender, System.Threading.ThreadExceptionEventArgs e)
        {
            LocalLogger.Error(e.Exception, "Excepci�n no controlada en hilo de Windows Forms (Application.ThreadException).");
        }

        /// <summary>
        /// Maneja excepciones no controladas que ocurren en el AppDomain.
        /// </summary>
        private static void CurrentDomain_UnhandledException(object sender, UnhandledExceptionEventArgs e)
        {
            if (e.ExceptionObject is Exception ex)
            {
                LocalLogger.Error(ex, "Excepci�n no controlada en AppDomain (CurrentDomain.UnhandledException).");
            }
            else
            {
                LocalLogger.Error("Se produjo una excepci�n no controlada en AppDomain, pero no se pudo castear a Exception.");
            }
        }
    }
}
